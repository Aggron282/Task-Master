const mongodb_connection = "mongodb+srv://marcokhodr116:aggron828@cluster0.81dhu2y.mongodb.net/task_master?retryWrites=true&w=majority&appName=Cluster0"


module.exports.mongodb_connection = mongodb_connection;
